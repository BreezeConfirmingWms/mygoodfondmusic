1. Block the application with a firewall or put the following entry into hosts file

127.0.0.1 licensing.scitools.com

2. Open the licensing dialog and select request offline code

3. Execute kg and put the license request code from the app

4. The keygen will provide the Replay code and the expiration date

5. Past the replay code into the app and fill in both dates

(expiration and maintenance) with the date from keygen

6. Click OK

7. Enjoy!
